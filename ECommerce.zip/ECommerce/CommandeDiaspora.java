package ECommerce;

public class CommandeDiaspora extends Commande
{

	protected void calculeTva() {
		
   {
	  montantTva = montantHt * (0.15 + 0.1);
    }
	}


	}



