package ECommerce;

public class Utilisateur {

	public static void main(String[] args)
	{
		Commande commandeLocale = new CommandeLocale();
		commandeLocale.setMontantHt (10000);
	    commandeLocale.calculeMontantTtc();
	    commandeLocale.affiche();
	    
	    Commande commandeDiaspora = new CommandeDiaspora();
	    commandeDiaspora.setMontantHt(20000);
	    commandeDiaspora.calculeMontantTtc();
	    commandeDiaspora.affiche();
	}
}
