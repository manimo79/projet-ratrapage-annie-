package ECommerce;

public class CommandeLocale extends Commande 
{
	
	//public CommandeLocale() {
//	}

	protected void calculeTva() {
		{	
	}
montantTva = montantHt * 0.1925;
}
	
	}


