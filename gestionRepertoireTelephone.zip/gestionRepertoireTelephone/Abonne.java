package gestionRepertoireTelephone;

public class Abonne {
public Abonne (String nom, String numero)
{
	this.nom=nom; this.numero=numero;
}
public String getNom() {return nom;}
public String getnumero() {return numero;}
private String nom, numero;
}
	


