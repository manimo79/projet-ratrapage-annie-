package gestionRepertoireTelephone;

public class TestRep {

	public static void main(String[] args) {
		
		Repert rep=new Repert(20);
		System.out.println((" il y a " + rep.getNAbonnes() + " abonnes "));
		
		Abonne a=new Abonne("Martin", "67-56-10-05 ");
		Abonne b= new Abonne("henri", " 67-54-22-15");
		
		rep.addAbonne(a);
		rep.addAbonne(b);
		rep.addAbonne(new Abonne (" Micheline "," 67-52-66-15"));
		rep.addAbonne(new Abonne (" serena ", " 66-22-410 "));
		
		System.out.println("il y a " + rep.getNAbonnes() + " abonne");
		System.out.println(" qui sont : ");
		
		for (int i=0; i<rep.getNAbonnes(); i++)
		{
			System.out.println(rep.getAbonne(i).getNom() + "" + rep.getAbonne(i));
			Abonne[]abonnes=rep.getAbonnesTries();
			
			for (int j=0; j<abonnes.length; j++)
				System.out.println(abonnes[j].getNom()+ "" +abonnes[j].getnumero());
		}
	}

}
